﻿Imports Microsoft.VisualBasic



Namespace core



    Public Class ctxDO

        Public Property CIDo As New CID

        'Public Function getctxlink() As String

        '    Dim link As String
        '    Dim cid As Integer = 0

        '    If Not (CIDo.CID Is Nothing) Then
        '        cid = Convert.ToInt16(CIDo.CID)
        '    End If

        '    Select Case cid
        '        Case Is = 577
        '            link = "http://STCCORETEST.controltex.com"
        '        Case Is = 587
        '            link = "http://STCCAR.controltex.com/"
        '        Case Is = 597
        '            link = "http://STCSTT.controltex.com"
        '        Case Else
        '            link = "NoString"
        '    End Select

        '    Return link

        'End Function

    End Class



End Namespace
