﻿Imports Microsoft.VisualBasic


Namespace core



    Public Class MasterSessionDAO
        Public Shared BaseUri As String
        Public Shared fromdate As String
        Public Shared todate As String


    End Class


End Namespace
