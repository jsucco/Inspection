﻿
Partial Class APP_MasterPage_blank
    Inherits System.Web.UI.MasterPage
End Class

