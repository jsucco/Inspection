﻿Imports Microsoft.VisualBasic

Namespace System.Web
    Public Class HttpHostedFile

    End Class
End Namespace
