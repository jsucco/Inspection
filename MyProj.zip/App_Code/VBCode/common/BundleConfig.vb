﻿Imports Microsoft.VisualBasic
Imports System.Web.Optimization

Namespace core

    Public Class BundleConfig

        Public Shared Sub RegisterBundles(ByVal Bundle As BundleCollection)



        End Sub

    End Class

End Namespace