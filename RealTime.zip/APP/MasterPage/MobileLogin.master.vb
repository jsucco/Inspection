﻿


Namespace core


    Partial Class APP_MasterPage_MobileLogin
        Inherits System.Web.UI.MasterPage
    End Class

End Namespace