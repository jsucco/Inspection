﻿



Namespace core



    Partial Class Training_TrainingVideo
        Inherits System.Web.UI.Page

    End Class
End Namespace