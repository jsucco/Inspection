﻿
Partial Class APP_Presentation_FlgBrd4_MaintenanceScheduleEditor
    Inherits System.Web.UI.Page

    Sub page_load(sender As Object, e As EventArgs) Handles Me.Load
        Response.Redirect("http://maintenance.standardtextile.com")
    End Sub

End Class
