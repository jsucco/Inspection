﻿
Partial Class APP_DataEntry_SPCInspectionInput
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Response.Redirect("~/APP/Mob/SPCInspectionInput.aspx")
    End Sub
End Class
