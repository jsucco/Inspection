﻿Imports System.Web.Security
Imports System.Security.Principal
Imports System.Threading
Imports core.Environment
Imports System.Reflection
Imports System.Net.NetworkInformation

Namespace core


    Partial Class APP_MasterPage_STCDashboard
        Inherits System.Web.UI.MasterPage

        Private Sub on_load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MainContent.Load




        End Sub

    
    End Class

End Namespace